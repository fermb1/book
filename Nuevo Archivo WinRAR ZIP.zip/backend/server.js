import express, { json } from 'express';
import dotenv from 'dotenv';
import cookieParser from 'cookie-parser';
import { connectDB } from './lib/db.js';
import pageroutes from './routes/page.routes.js'; // Importa las rutas de páginas
dotenv.config();
const app = express();
const PORT = process.env.PORT || 5000;
import cors from 'cors';
// Conexión a la base de datos
connectDB();
import Pag from './models/Pag.model.js';
// Middlewares
app.use(
    cors({
      origin: 'http://localhost:5173', // Origen permitido
      credentials: true,               // Permite cookies y encabezados de autorización
    })
  );
  app.use(express.json());
app.use(cookieParser());

// Rutas
app.use("/api/pages", pageroutes);

// Ruta raíz
app.get('/', (req, res) => {
    res.send('Bienvenido a la página principal');
});
app.put('/api/pages/:id', async (req,res) => {
  const { id } = req.params;
  const { text } = req.body;
  try {
    const updatePage = await Pag.findByIdAndUpdate(
      id,
      { text },
      { new: false } // Retorna el documento actualizado
    );
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(404).json({error: 'pagina no encontrada'})
    }
    res.json(updatePage);

  } catch (error) {
    res.status(500).json({ error: 'error al actualizar la pagina'})
  }
})
// Iniciar el servidor
app.listen(PORT, () => {
    console.log(`Server running on port http://localhost:` + PORT);
});

console.log(process.env.PORT);
