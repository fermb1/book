import express from "express";
import createPage from "../controllers/createpage.controller.js"; // Ajusta la ruta al archivo
import getPages from "../controllers/getpages.controller.js";
const router = express.Router();

// Ruta para crear una nueva página
router.post('/create', createPage);
router.get('/all', getPages);

export default router;
